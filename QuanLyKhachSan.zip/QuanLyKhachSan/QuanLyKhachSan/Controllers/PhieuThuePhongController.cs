﻿using QuanLyKhachSan.Models;
using QuanLyKhachSan.Models.Domain;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace QuanLyKhachSan.Controllers
{
    public class PhieuThuePhongController : Controller
    {
        DbKhachSanContext _db = new DbKhachSanContext();

        // GET: PhieuThuePhong
        //public PhieuThuePhong getPhieuThuePhong()
        //{
        //    PhieuThuePhong phieuThuePhong = Session["PhieuThuePhong"] as PhieuThuePhong;
        //    if (phieuThuePhong == null || Session["PhieuThuePhong"] == null)
        //    {
        //        phieuThuePhong = new PhieuThuePhong();
        //        Session["PhieuThuePhong"] = phieuThuePhong;
        //    }
        //    return phieuThuePhong;
        //}

        [HttpGet]
        public ActionResult ThemPhong(int id)
        {
            //PhieuThuePhong phieuThuePhong = getPhieuThuePhong();

            PhieuThuePhong phieuThuePhong = new PhieuThuePhong();

            var room = _db.Rooms.SingleOrDefault(s => s.id_room == id);

            var room_detail = _db.RoomDetails.SingleOrDefault(s => s.id_roomType == room.id_roomType);

            int suc_chua = room_detail.SucChua;
            List<int> list_so_luong_khach = new List<int>();
            for (int i = 0; i <= suc_chua; i++)
            {
                list_so_luong_khach.Add(i);
            }
            //ViewBag.So_luong_khach = list_so_luong_khach;

            ViewBag.so_luong_khach = new SelectList(list_so_luong_khach, "so_luong_khach");
            //List<int> Nums = (List<int>)ViewBag.So_luong_khach;
            if (room != null)
            {
                phieuThuePhong.Hinh_phong = room.image_room;
                phieuThuePhong.customer_id = int.Parse(Session["ID_customer"].ToString());
                phieuThuePhong.room_id = room.id_room;
            }
            return View(phieuThuePhong);
        }
        [HttpPost]
        public ActionResult ThemPhong(int id, PhieuThuePhong phieuThuePhong)
        {
            var room = _db.Rooms.SingleOrDefault(s => s.id_room == id);
            var room_detail = _db.RoomDetails.SingleOrDefault(s => s.id_roomType == room.id_roomType);

            int suc_chua = room_detail.SucChua;
            List<int> list_so_luong_khach = new List<int>();
            for (int i = 0; i <= suc_chua; i++)
            {
                list_so_luong_khach.Add(i);
            }


            ViewBag.so_luong_khach = new SelectList(list_so_luong_khach, "so_luong_khach");

            try
            {

                if (room != null)
                {
                    phieuThuePhong.room_id = room.id_room;

                    phieuThuePhong.customer_id = int.Parse(Session["ID_customer"].ToString());

                    if (int.Parse(Session["ID_customer"].ToString()) != 1)
                    {
                        phieuThuePhong.have_Foreign = true;
                    }
                    //getPhieuThuePhong().Them(room);
                }
                if (ModelState.IsValid)
                {
                    _db.Configuration.ValidateOnSaveEnabled = true;

                    _db.PhieuThuePhongs.Add(phieuThuePhong);
                    _db.SaveChanges();
                    return RedirectToAction("PhieuThuePhong_Success", "PhieuThuePhong");
                }
                else
                {
                    return View(phieuThuePhong);
                }
                
            }
            catch
            {
                throw;
            }
        }

        public ActionResult danh_sach_phong_da_dat(string searchBy)
        {
            int id_customer = int.Parse(Session["ID_customer"].ToString());
            List<PhieuThuePhong> phieuThuePhongs_list = new List<PhieuThuePhong>();
            phieuThuePhongs_list = _db.PhieuThuePhongs.Where(ptp => ptp.customer_id == id_customer).ToList();
            List<Room> rooms = new List<Room>();
            foreach(var ptp in phieuThuePhongs_list)
            {
                foreach(var room in _db.Rooms)
                {
                    if(ptp.room_id == room.id_room)
                    {
                        rooms.Add(room);
                        ptp.Hinh_phong = room.image_room;
                        break;
                    }
                }
            }

            foreach (var room in rooms)
            {
                foreach (var room_detail in _db.RoomDetails)
                {
                    if (room.id_roomType == room_detail.id_roomType)
                    {
                        room.ten_phong = room_detail.ten_phong;
                        room.Price = room_detail.Price;
                        break;
                    }
                }
            }

            foreach (var ptp in phieuThuePhongs_list)
            {
                foreach (var room in rooms)
                {
                    if (ptp.room_id == room.id_room)
                    {
                        ptp.Ten_phong = room.ten_phong;
                        ptp.GiaPhong = room.Price;
                        break;
                    }
                }
            }

            foreach (var ptp in phieuThuePhongs_list)
            {
                ptp.tong_so_ngay_thue = (int)(ptp.end_day - ptp.start_day).TotalDays;
                int tong_tien = ptp.GiaPhong * ptp.tong_so_ngay_thue;
                if (ptp.so_luong_khach == 3)
                {
                    ptp.tong_don_gia = tong_tien + (tong_tien * 25) / 100;
                    if (int.Parse(Session["ID_loaiKhach"].ToString()) != 1 || ptp.have_Foreign == true)
                    {
                        ptp.tong_don_gia = 2 * (tong_tien + (tong_tien * 25) / 100);
                    }
                }
                else if (int.Parse(Session["ID_loaiKhach"].ToString()) != 1 || ptp.have_Foreign == true)
                {
                    ptp.tong_don_gia = 2 * (tong_tien);
                }
                else
                {
                    ptp.tong_don_gia = tong_tien;
                }
            }

            if (searchBy == "da_thanh_toan")
                return View(phieuThuePhongs_list.Where(s => s.tinh_trang_phieu_thue_phong == true).ToList());
            else if (searchBy == "chua_thanh_toan")
                return View(phieuThuePhongs_list.Where(s => s.tinh_trang_phieu_thue_phong == false).ToList());
            else
                return View(phieuThuePhongs_list);

        }


        //public ActionResult ShowListRoom()
        //{
        //    if (Session["PhieuThuePhong"] == null)
        //    {
        //        return RedirectToAction("ShowListRoom", "PhieuThuePhong");
        //    }
        //    PhieuThuePhong phieuThuePhong = Session["PhieuThuePhong"] as PhieuThuePhong;
        //    return View(phieuThuePhong);
        //}

        //public ActionResult Update_Quantity_PhieuThuePhong(FormCollection form)
        //{
        //    PhieuThuePhong phieuThuePhong = Session["PhieuThuePhong"] as PhieuThuePhong;
        //    int ID_room = int.Parse(form["ID_Room"]);
        //    int quantity = int.Parse(form["Quantity"]);
        //    //phieuThuePhong.Update_quantity_SoLuongPhongDat(ID_room, quantity);
        //    return RedirectToAction("ShowListRoom", "PhieuThuePhong");
        //}

        //public ActionResult HuyPhong(int id)
        //{
        //    return View(_db.PhieuThuePhongs.Where(s => s.id_phieu_thue_phong == id).FirstOrDefault());
        //}
        //[HttpPost]
        //public ActionResult HuyPhong(int id)
        //{
        //    PhieuThuePhong phieuThuePhong = Session["PhieuThuePhong"] as PhieuThuePhong;
        //    phieuThuePhong.Huy_phong(id);
        //    _db.PhieuThuePhongs.Remove(phieuThuePhong);
        //    _db.SaveChanges();
        //    return RedirectToAction("ShowListRoom", "PhieuThuePhong");
        //}

        public ActionResult Delete(int id)
        {
            var ptp = _db.PhieuThuePhongs.Where(p => p.id_phieu_thue_phong == id).FirstOrDefault();
            return View(ptp);
        }
        [HttpPost]
        public ActionResult Delete(int id, PhieuThuePhong phieuThuePhong)
        {
            try
            {
                // TODO: Add delete logic here
                phieuThuePhong = _db.PhieuThuePhongs.Where(p => p.id_phieu_thue_phong == id).FirstOrDefault();
                _db.PhieuThuePhongs.Remove(phieuThuePhong);
                _db.SaveChanges();
                return RedirectToAction("danh_sach_phong_da_dat", "PhieuThuePhong");
            }
            catch
            {
                return RedirectToAction("danh_sach_phong_da_dat", "PhieuThuePhong");
            }
        }

        //public PartialViewResult BagRoom()
        //{
        //    int _t_item = 0;
        //    PhieuThuePhong phieuThuePhong = Session["PhieuThuePhong"] as PhieuThuePhong;
        //    if (phieuThuePhong != null)
        //    {
        //        _t_item = phieuThuePhong.Total_Quantity();
        //    }
        //    ViewBag.infoPhieuThuePhong = _t_item;
        //}
        public PartialViewResult BagRoom()
        {
            int id_current_customer = int.Parse(Session["ID_customer"].ToString());
            PhieuThuePhong ptp = new PhieuThuePhong();
            ptp.phieuThuePhongs = _db.PhieuThuePhongs.Where(p => p.customer_id == id_current_customer && p.tinh_trang_phieu_thue_phong == false).ToList();

            ViewBag.infoPhieuThuePhong = ptp.phieuThuePhongs.Count;
            return PartialView("BagRoom");
        }

        //public ActionResult CheckOut(FormCollection form)
        //{
        //    try
        //    {
        //        PhieuThuePhong phieuThuePhong = Session["PhieuThuePhong"] as PhieuThuePhong;
        //        PhieuThuePhong _phieuThuePhong = new PhieuThuePhong();
        //        _phieuThuePhong.room_id = int.Parse(form["Idroom"]);
        //        _phieuThuePhong.customer_id = int.Parse(form["IdCustomer"]);
        //        _phieuThuePhong.start_day = DateTime.Now;
        //        _phieuThuePhong.GiaPhong = int.Parse(form["Gia"]);
        //        _db.PhieuThuePhongs.Add(_phieuThuePhong);
        //        foreach (var item in phieuThuePhong.Items)
        //        {
        //            Bill _bill = new Bill();
        //            _bill.phieu_thue_phong_id = _phieuThuePhong.id_phieu_thue_phong;
        //            //_bill.bao_cao_id = item._hotel_room
        //            _db.Bills.Add(_bill);
        //        }
        //        _db.SaveChanges();
        //        phieuThuePhong.ClearPhieuThuePhong();
        //        return RedirectToAction("PhieuThuePhong_Success", "PhieuThuePhong");
        //    }
        //    catch
        //    {
        //        return Content("Error checkout.");
        //    }
        //}

        public ActionResult PhieuThuePhong_Success()
        {
            return View();
        }
    }
}