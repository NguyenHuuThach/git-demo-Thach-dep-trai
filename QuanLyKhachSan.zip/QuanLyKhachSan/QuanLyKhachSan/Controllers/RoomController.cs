﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QuanLyKhachSan.Models;
using QuanLyKhachSan.Models.Domain;
using System.Data;
using System.IO;
using System.Data.Entity;

namespace QuanLyKhachSan.Controllers
{
    public class RoomController : Controller
    {
        DbKhachSanContext _db = new DbKhachSanContext();

        // GET: Room
        public ActionResult Index(string searchBy, string search)
        {
            List<Room> list_room = new List<Room>();
            list_room = _db.Rooms.ToList();
            List<RoomDetail> list_room_detail = new List<RoomDetail>();
            list_room_detail = _db.RoomDetails.ToList();

            foreach (Room room in list_room)
            {
                foreach (RoomDetail roomDetail in list_room_detail)
                {
                    if(room.id_roomType == roomDetail.id_roomType)
                    {
                        room.Price = roomDetail.Price;
                        room.ten_phong = roomDetail.ten_phong;
                        break;
                    }
                }
            }
            if (searchBy == "TenPhong")
                return View(list_room.Where(s => s.ten_phong.StartsWith(search)).ToList());
            else if(searchBy == "TinhTrang")
                return View(list_room.Where(s => s.tinhTrang.StartsWith(search)).ToList());
            else if (searchBy == "GiaPhong")
                return View(list_room.Where(s => s.Price.ToString().StartsWith(search)).ToList());
            else
                return View(list_room);
        }

        // GET: Room/Details/5
        public ActionResult Details(int id)
        {
            Room room = new Room();
            room = _db.Rooms.Where(s => s.id_room == id).FirstOrDefault();
            RoomDetail roomDetail = new RoomDetail();
            roomDetail = _db.RoomDetails.Where(s => s.id_roomType == room.id_roomType).FirstOrDefault();
            room.Price = roomDetail.Price;
            room.ten_phong = roomDetail.ten_phong;

            return View(room);
        }

        // GET: Room/Create
        public ActionResult Create()
        {
            Room room = new Room();
            ViewBag.id_roomType = new SelectList(_db.RoomDetails, "id_roomType", "ten_phong");

            return View(room);
        }

        // POST: Room/Create
        [HttpPost]
        public ActionResult Create(Room room)
        {
            ViewBag.id_roomType = new SelectList(_db.RoomDetails, "id_roomType", "ten_phong");

            try
            {
                // TODO: Add insert logic here
                
                if (room.imageUpload != null)
                {
                    string file = Path.GetFileNameWithoutExtension(room.imageUpload.FileName);
                    string extension = Path.GetExtension(room.imageUpload.FileName);
                    file = file + extension;
                    room.image_room = "~/Content/Images/" + file;
                    room.imageUpload.SaveAs(Path.Combine(Server.MapPath("~/Content/Images"), file));
                }

                _db.Rooms.Add(room);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Room/Edit/5
        public ActionResult Edit(int id)
        {
            return View(_db.Rooms.Where(s => s.id_room == id).FirstOrDefault());
        }

        // POST: Room/Edit/5
        [HttpPost]
        public ActionResult Edit(Room room)
        {
            try
            {
                // TODO: Add update logic here
                if (room.imageUpload != null)
                {
                    string file = Path.GetFileNameWithoutExtension(room.imageUpload.FileName);
                    string extension = Path.GetExtension(room.imageUpload.FileName);
                    file = file + extension;
                    room.image_room = "~/Content/Images/" + file;
                    room.imageUpload.SaveAs(Path.Combine(Server.MapPath("~/Content/Images"), file));
                }
                _db.Entry(room).State = EntityState.Modified;
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Room/Delete/5
        public ActionResult Delete(int id)
        {
            Room room = new Room();
            room = _db.Rooms.Where(s => s.id_room == id).FirstOrDefault();
            RoomDetail roomDetail = new RoomDetail();
            roomDetail = _db.RoomDetails.Where(s => s.id_roomType == room.id_roomType).FirstOrDefault();
            room.Price = roomDetail.Price;
            room.ten_phong = roomDetail.ten_phong;
            return View(room);
        }

        // POST: Room/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, Room room)
        {
            try
            {
                // TODO: Add delete logic here
                room = _db.Rooms.Where(s => s.id_room == id).FirstOrDefault();
                _db.Rooms.Remove(room);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
