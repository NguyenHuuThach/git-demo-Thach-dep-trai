﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using QuanLyKhachSan.Models;
using QuanLyKhachSan.Models.Domain;

namespace QuanLyKhachSan.Controllers
{
    public class HomeController : Controller
    {
        DbKhachSanContext _db = new DbKhachSanContext();
        //Sign up
        public ActionResult SignUp()
        {
            ViewBag.id_Loai_khach_hang = new SelectList(_db.LoaiKhachHangs, "id_Loai_khach_hang", "loai_khach");
            return View();
        }
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult SignUp(/*[Bind(Include = "id_customer,name_customer,address_customer,id_Loai_khach_hang,email_customer,password_customer,confirm_password_customer")]*/ Customer _customer)
        {
            ViewBag.id_Loai_khach_hang = new SelectList(_db.LoaiKhachHangs, "id_Loai_khach_hang", "loai_khach");
            
            if (ModelState.IsValid)
            {
                var check = _db.Customers.FirstOrDefault(s => s.email_customer == _customer.email_customer);
                if(check == null)
                {
                    _db.Configuration.ValidateOnSaveEnabled = true;

                    _db.Customers.Add(_customer);
                    _db.SaveChanges();
                    Session["email_customer"] = _customer.email_customer.ToString();
                    Session["ID_customer"] = _customer.id_customer.ToString();
                    Session["ID_loaiKhach"] = _customer.id_Loai_khach_hang.ToString();

                    //if(_customer.email_customer == "admin@gmail.com")
                    //{
                    //    return RedirectToAction("admin"); 
                    //}
                    return RedirectToAction("Index");
                }
                else
                {
                    ViewBag.error = "Tai khoan da ton tai";
                    return View();
                }
            }
            return View();
        }
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult NoiQui()
        {
            return View();
        }

        //Login
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(Customer _customer)
        {
            admin Admin = new admin();
            Admin.email_admin = _customer.email_customer;
            Admin.password_admin = _customer.password_customer;

            NhanVien nV = new NhanVien();
            nV.email_nhanVien = _customer.email_customer;
            nV.password_nhanVien = _customer.password_customer;

                    var check = _db.Customers.Where(s => s.email_customer == _customer.email_customer && 
                    s.password_customer.Equals(_customer.password_customer)).FirstOrDefault();

                    //Customer check_id = _db.Customers.Where(s => s.id_customer == _customer.id_customer && 
                    //s.password_customer.Equals(_customer.password_customer)).FirstOrDefault();

                    var check_admin = _db.Admins.Where(s => s.email_admin == Admin.email_admin &&
                    s.password_admin.Equals(Admin.password_admin)).FirstOrDefault();

                    var check_nhanVien = _db.NhanViens.Where(s => s.email_nhanVien == nV.email_nhanVien &&
                    s.password_nhanVien.Equals(nV.password_nhanVien)).FirstOrDefault();
            if (check != null)
                    {
                        //if(_customer.email_customer == "admin@gmail.com")
                        //{
                        //    Session["email_admin"] = _customer.email_customer.ToString();
                        //    return RedirectToAction("admin", _customer);
                        //}
                        //else
                        //{
                            Session["email_customer"] = check.email_customer.ToString();
                            Session["ID_customer"] = check.id_customer.ToString();
                            Session["ID_loaiKhach"] = check.id_Loai_khach_hang.ToString();

                            return RedirectToAction("Index","Home", _customer);
                        //}
                        
                    }
            else if (check_admin != null)
            {
                Session["email_admin"] = Admin.email_admin.ToString();
                return RedirectToAction("admin", Admin);
            }
            else if (check_nhanVien != null)
            {
                Session["email_nhanVien"] = nV.email_nhanVien.ToString();
                return RedirectToAction("nhan_vien", nV);
            }
            else
                {
                    ViewBag.error = "Tai khoan khong hop le";
                    return View();
                }
            
        }


        //logout
        public ActionResult Logout()
        {
            Session.Abandon();
            return RedirectToAction("Login", "Home");
        }

        public ActionResult ListCard(string searchBy, string search)
        {
            List<Room> list_room = new List<Room>();
            list_room = _db.Rooms.ToList();
            List<RoomDetail> list_room_detail = new List<RoomDetail>();
            list_room_detail = _db.RoomDetails.ToList();

            foreach (Room room in list_room)
            {
                foreach (RoomDetail roomDetail in list_room_detail)
                {
                    if (room.id_roomType == roomDetail.id_roomType)
                    {
                        room.Price = roomDetail.Price;
                        room.ten_phong = roomDetail.ten_phong;
                        break;
                    }
                }
            }

            if (searchBy == "TenPhong")
                return View(list_room.Where(s => s.ten_phong.StartsWith(search)).ToList());
            else if (searchBy == "TinhTrang")
                return View(list_room.Where(s => s.tinhTrang.StartsWith(search)).ToList());
            else if (searchBy == "GiaPhong")
                return View(list_room.Where(s => s.Price.ToString().StartsWith(search)).ToList());
            else
                return View(list_room);
        }

        public ActionResult ListCard2(string searchBy, string search)
        {
            List<Room> list_room = new List<Room>();
            list_room = _db.Rooms.ToList();
            List<RoomDetail> list_room_detail = new List<RoomDetail>();
            list_room_detail = _db.RoomDetails.ToList();

            foreach (Room room in list_room)
            {
                foreach (RoomDetail roomDetail in list_room_detail)
                {
                    if (room.id_roomType == roomDetail.id_roomType)
                    {
                        room.Price = roomDetail.Price;
                        room.ten_phong = roomDetail.ten_phong;
                        break;
                    }
                }
            }

            if (searchBy == "TenPhong")
                return View(list_room.Where(s => s.ten_phong.StartsWith(search)).ToList());
            else if (searchBy == "TinhTrang")
                return View(list_room.Where(s => s.tinhTrang.StartsWith(search)).ToList());
            else if (searchBy == "GiaPhong")
                return View(list_room.Where(s => s.Price.ToString().StartsWith(search)).ToList());
            else
                return View(list_room);
        }

        public ActionResult admin()
        {
            return View();
        }

        public ActionResult nhan_vien()
        {
            return View();
        }
    }
}