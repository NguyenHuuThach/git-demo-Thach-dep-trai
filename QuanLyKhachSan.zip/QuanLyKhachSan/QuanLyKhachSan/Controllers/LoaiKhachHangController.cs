﻿using QuanLyKhachSan.Models;
using QuanLyKhachSan.Models.Domain;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QuanLyKhachSan.Controllers
{
    public class LoaiKhachHangController : Controller
    {
        DbKhachSanContext _db = new DbKhachSanContext();
        // GET: LoaiKhachHang
        public ActionResult Index()
        {
            return View(_db.LoaiKhachHangs.ToList());
        }

        // GET: LoaiKhachHang/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: LoaiKhachHang/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: LoaiKhachHang/Create
        [HttpPost]
        public ActionResult Create(LoaiKhachHang loaiKhachHang)
        {
            try
            {
                // TODO: Add insert logic here
                _db.LoaiKhachHangs.Add(loaiKhachHang);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: LoaiKhachHang/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: LoaiKhachHang/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, LoaiKhachHang loaiKhachHang)
        {
            try
            {
                // TODO: Add update logic here

                _db.Entry(loaiKhachHang).State = EntityState.Modified;
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: LoaiKhachHang/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: LoaiKhachHang/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
