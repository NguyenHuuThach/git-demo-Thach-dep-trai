﻿using QuanLyKhachSan.Models;
using QuanLyKhachSan.Models.Domain;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QuanLyKhachSan.Controllers
{
    public class RoomDetailController : Controller
    {
        DbKhachSanContext _db = new DbKhachSanContext();
        // GET: RoomDetail
        public ActionResult Index()
        {
            return View(_db.RoomDetails.ToList());
        }

        // GET: RoomDetail/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: RoomDetail/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: RoomDetail/Create
        [HttpPost]
        public ActionResult Create(RoomDetail roomDetail)
        {
            try
            {
                // TODO: Add insert logic here
                _db.RoomDetails.Add(roomDetail);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: RoomDetail/Edit/5
        public ActionResult Edit(int id)
        {
            return View(_db.RoomDetails.Where(s => s.id_roomType == id).FirstOrDefault());
        }

        // POST: RoomDetail/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, RoomDetail roomDetail)
        {
            try
            {
                // TODO: Add update logic here
                _db.Entry(roomDetail).State = EntityState.Modified;
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: RoomDetail/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: RoomDetail/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
