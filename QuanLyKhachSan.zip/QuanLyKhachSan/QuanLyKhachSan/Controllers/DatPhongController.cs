﻿using QuanLyKhachSan.Models;
using QuanLyKhachSan.Models.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QuanLyKhachSan.Controllers
{
    public class DatPhongController : Controller
    {
        DbKhachSanContext _db = new DbKhachSanContext();

        // GET: DatPhong

        public DanhSachDatPhong getDanhSachDatPhong()
        {
            DanhSachDatPhong danhSachDatPhong = Session["DanhSachDatPhong"] as DanhSachDatPhong;
            if (danhSachDatPhong == null || Session["DanhSachDatPhong"] == null)
            {
                danhSachDatPhong = new DanhSachDatPhong();
                Session["DanhSachDatPhong"] = danhSachDatPhong;
            }
            return danhSachDatPhong;
        }
        
        // đáng lẽ phải trả ra 1 cái form làm ra phiếu thuê phòng
        // chỉnh lại tình trạng phòng
        public ActionResult ThemPhong(int id)
        {
            var room = _db.Rooms.SingleOrDefault(s => s.id_room == id);
            if (room != null)
            {
                getDanhSachDatPhong().Them(room);
            }
            return RedirectToAction("ShowListRoom", "DatPhong");
        }
        //
        public ActionResult ShowListRoom()
        {
            if (Session["DanhSachDatPhong"] == null)
            {
                return RedirectToAction("ShowListRoom", "DatPhong");
            }
            DanhSachDatPhong danhSachDatPhong = Session["DanhSachDatPhong"] as DanhSachDatPhong;
            return View(danhSachDatPhong);
        }

        public ActionResult Update_Quantity_DanhSachDatPhong(FormCollection form)
        {
            DanhSachDatPhong danhSachDatPhong = Session["DanhSachDatPhong"] as DanhSachDatPhong;
            int ID_room =int.Parse(form["ID_Room"]);
            int quantity = int.Parse(form["Quantity"]);
            danhSachDatPhong.Update_quantity_SoLuongPhongDat(ID_room, quantity);
            return RedirectToAction("ShowListRoom", "DatPhong");
        }
        //
        public ActionResult HuyPhong(int id)
        {
            DanhSachDatPhong danhSachDatPhong = Session["DanhSachDatPhong"] as DanhSachDatPhong;
            danhSachDatPhong.Huy_phong(id);
            return RedirectToAction("ShowListRoom", "DatPhong");
        }

        public PartialViewResult BagRoom()
        {
            int _t_item = 0;
            DanhSachDatPhong danhSachDatPhong = Session["DanhSachDatPhong"] as DanhSachDatPhong;
            if(danhSachDatPhong != null)
            {
                _t_item = danhSachDatPhong.Total_Quantity();
            }
            ViewBag.infoDanhSachDatPhong = _t_item;
            return PartialView("BagRoom");
        }

        public ActionResult CheckOut(FormCollection form)
        {
            try
            {
                DanhSachDatPhong danhSachDatPhong = Session["DanhSachDatPhong"] as DanhSachDatPhong;
                PhieuThuePhong _phieuThuePhong = new PhieuThuePhong();
                _phieuThuePhong.start_day = DateTime.Now;
                _phieuThuePhong.customer_id = int.Parse(form["IdCustomer"]);
                _phieuThuePhong.GiaPhong = int.Parse(form["Gia"]);
                _db.PhieuThuePhongs.Add(_phieuThuePhong);
                foreach(var item in danhSachDatPhong.Items)
                {
                    Bill _bill = new Bill();
                    _bill.phieu_thue_phong_id = _phieuThuePhong.id_phieu_thue_phong;
                    //_bill.bao_cao_id = item._hotel_room
                    _db.Bills.Add(_bill);
                }
                _db.SaveChanges();
                danhSachDatPhong.ClearDanhSachDatPhong();
                return RedirectToAction("datPhong_Success", "DatPhong");
            }
            catch
            {
                return Content("Error checkout.");
            }
        }
        public ActionResult datPhong_Success()
        {
            return View();
        }
    }
}