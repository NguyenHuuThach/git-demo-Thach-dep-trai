﻿using QuanLyKhachSan.Models;
using QuanLyKhachSan.Models.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QuanLyKhachSan.Controllers
{
    public class BillController : Controller
    {
        DbKhachSanContext _db = new DbKhachSanContext();

        // GET: Bill
        public ActionResult Index(string searchBy)
        {
            List<PhieuThuePhong> phieuThuePhongs_list = new List<PhieuThuePhong>();
            phieuThuePhongs_list = _db.PhieuThuePhongs.ToList();
            List<Room> rooms = new List<Room>();

            foreach (var ptp in phieuThuePhongs_list)
            {
                foreach (var room in _db.Rooms)
                {
                    if (ptp.room_id == room.id_room)
                    {
                        rooms.Add(room);
                        ptp.Hinh_phong = room.image_room;
                        break;
                    }
                }
            }

            foreach (var ptp in phieuThuePhongs_list)
            {
                foreach (var bill in _db.Bills)
                {
                    if (ptp.id_phieu_thue_phong == bill.phieu_thue_phong_id)
                    {
                        ptp.tong_don_gia = bill.total_price;
                        ptp.tong_so_ngay_thue = bill.so_ngay_thue;
                        break;
                    }
                }
            }

            foreach (var room in rooms)
            {
                foreach (var room_detail in _db.RoomDetails)
                {
                    if (room.id_roomType == room_detail.id_roomType)
                    {
                        room.ten_phong = room_detail.ten_phong;
                        room.Price = room_detail.Price;
                        break;
                    }
                }
            }

            foreach (var ptp in phieuThuePhongs_list)
            {
                foreach (var room in rooms)
                {
                    if (ptp.room_id == room.id_room)
                    {
                        ptp.Ten_phong = room.ten_phong;
                        ptp.GiaPhong = room.Price;
                        break;
                    }
                }
            }

            foreach (var ptp in phieuThuePhongs_list)
            {
                foreach (var cus in _db.Customers)
                {
                    if (ptp.customer_id == cus.id_customer)
                    {
                        ptp.ten_khach_hang = cus.name_customer;
                        ptp.loai_khach_id = cus.id_Loai_khach_hang;
                        break;
                    }
                }
            }

            foreach (var ptp in phieuThuePhongs_list)
            {
                foreach (var cus_type in _db.LoaiKhachHangs)
                {
                    if (ptp.loai_khach_id == cus_type.id_Loai_khach_hang)
                    {
                        ptp.loai_khach = cus_type.loai_khach;
                        break;
                    }
                }
            }

            if (searchBy == "da_thanh_toan")
                return View(phieuThuePhongs_list.Where(s => s.tinh_trang_phieu_thue_phong == true).ToList());
            else if (searchBy == "chua_thanh_toan")
                return View(phieuThuePhongs_list.Where(s => s.tinh_trang_phieu_thue_phong == false).ToList());
            else
                return View(phieuThuePhongs_list);
        }

        //public ActionResult CheckOut(FormCollection form)
        //{
        //    try
        //    {
        //        PhieuThuePhong phieuThuePhong = Session["PhieuThuePhong"] as PhieuThuePhong;
        //        PhieuThuePhong _phieuThuePhong = new PhieuThuePhong();
        //        _phieuThuePhong.room_id = int.Parse(form["Idroom"]);
        //        _phieuThuePhong.customer_id = int.Parse(form["IdCustomer"]);
        //        _phieuThuePhong.start_day = DateTime.Now;
        //        _phieuThuePhong.GiaPhong = int.Parse(form["Gia"]);
        //        _db.PhieuThuePhongs.Add(_phieuThuePhong);
        //        foreach (var item in phieuThuePhong.Items)
        //        {
        //            Bill _bill = new Bill();
        //            _bill.phieu_thue_phong_id = _phieuThuePhong.id_phieu_thue_phong;
        //            //_bill.bao_cao_id = item._hotel_room
        //            _db.Bills.Add(_bill);
        //        }
        //        _db.SaveChanges();
        //        phieuThuePhong.ClearPhieuThuePhong();
        //        return RedirectToAction("PhieuThuePhong_Success", "PhieuThuePhong");
        //    }
        //    catch
        //    {
        //        return Content("Error checkout.");
        //    }
        //}

        // GET: Bill/Details/5

        public ActionResult thanh_toan(int id)
        {
            try
            {
                PhieuThuePhong ptp = _db.PhieuThuePhongs.Where(p => p.id_phieu_thue_phong == id && p.tinh_trang_phieu_thue_phong == false).FirstOrDefault();
                if(ptp != null)
                {
                    Customer customer = _db.Customers.Where(c => c.id_customer == ptp.customer_id).FirstOrDefault();
                    LoaiKhachHang loaiKhachHang = _db.LoaiKhachHangs.Where(c => c.id_Loai_khach_hang == customer.id_Loai_khach_hang).FirstOrDefault();
                    Room room = _db.Rooms.Where(r => r.id_room == ptp.room_id).FirstOrDefault();
                    RoomDetail roomDetail = _db.RoomDetails.Where(r => r.id_roomType == room.id_roomType).FirstOrDefault();

                    ptp.GiaPhong = roomDetail.Price;
                    ptp.loai_khach_id = customer.id_Loai_khach_hang;
                    ptp.loai_khach = loaiKhachHang.loai_khach;

                    Bill bill = new Bill();

                    bill.phieu_thue_phong_id = ptp.id_phieu_thue_phong;
                    bill.so_ngay_thue = (int)(ptp.end_day - ptp.start_day).TotalDays;
                    int tong_tien = ptp.GiaPhong * bill.so_ngay_thue;

                    if (ptp.so_luong_khach == roomDetail.SucChua)
                    {
                        bill.total_price = tong_tien + (tong_tien * 25) / 100;
                        if(customer.id_Loai_khach_hang != 1 || ptp.have_Foreign != false)
                        {
                            bill.total_price = 2*(tong_tien + (tong_tien * 25) / 100);
                        }
                    }
                    else if(customer.id_Loai_khach_hang != 1 || ptp.have_Foreign != false)
                    {
                        bill.total_price = 2 * (tong_tien);
                    }    
                    else
                    {
                        bill.total_price = tong_tien;
                    }

                    _db.Bills.Add(bill);
                    _db.SaveChanges();
                }
                return RedirectToAction("Index", "Bill");
            }
            catch
            {
                return Content("Error checkout.");
            }
        }

        public ActionResult Detail(int id)
        {
            return View();
        }

        // GET: Bill/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Bill/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Bill/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Bill/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Bill/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Bill/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
