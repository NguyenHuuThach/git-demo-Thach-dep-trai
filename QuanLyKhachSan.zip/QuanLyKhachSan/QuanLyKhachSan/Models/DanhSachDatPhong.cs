﻿using QuanLyKhachSan.Models.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace QuanLyKhachSan.Models
{
    public class DanhSachDatPhongItem
    {
        public Room _hotel_room { get; set; } // Cái phòng muốn đặt
        public int _list_quantity { get; set; } // cái này số lượng chỉ có 1 thôi
    }
    public class DanhSachDatPhong
    {
        // danh sách mấy cái phòng mình đặt
        List<DanhSachDatPhongItem> items = new List<DanhSachDatPhongItem>(); 

        // method lấy ra cái danh sách ở trên
        public IEnumerable<DanhSachDatPhongItem> Items
        {
            get { return items; }
        }

        // method đặt phòng 
        public void Them(Room room, int _quantity = 1)
        {
            var item = items.FirstOrDefault(s => s._hotel_room.id_room == room.id_room);
            if (item == null)
            {
                items.Add(new DanhSachDatPhongItem
                {
                    _hotel_room = room,
                    _list_quantity = _quantity
                });
            }
            else
            {
                item._list_quantity += _quantity;
            }
        }

        // method cập nhật số lượng từng loại phòng đã đặt (nhưng chỉ có 1 thôi)
        public void Update_quantity_SoLuongPhongDat(int id, int _quantity)
        {
            var item = items.Find(s => s._hotel_room.id_room == id);
            if (item != null)
            {
                item._list_quantity = _quantity;
            }
        }

        // tổng tiền khách hàng phải trả
        public int Total_money()
        {
            var total = items.Sum(s => s._hotel_room.Price * s._list_quantity);
            return total;
        }

        // hủy phòng
        public void Huy_phong(int id)
        {
            items.RemoveAll(s => s._hotel_room.id_room == id);
        }

        // số lượng tổng hết các phòng mình đặt
        public int Total_Quantity()
        {
            return items.Sum(s => s._list_quantity);
        }

        // method clear sau khi đã thanh toán ( nhưng không cần memthod này )
        public void ClearDanhSachDatPhong()
        {
            items.Clear();
        }
    }
}