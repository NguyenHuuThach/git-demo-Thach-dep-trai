﻿using QuanLyKhachSan.Models.Domain;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace QuanLyKhachSan.Models
{
    public class DbKhachSanContext : DbContext
    {
        public DbKhachSanContext() : base("DbKhachSanContext") { }
        public DbKhachSanContext(string connectionString) : base(connectionString) { }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<LoaiKhachHang> LoaiKhachHangs { get; set; }
        public DbSet<PhieuThuePhong> PhieuThuePhongs { get; set; }
        public DbSet<Room> Rooms { get; set; }
        public DbSet<RoomDetail> RoomDetails { get; set; }
        public DbSet<Bill> Bills { get; set; }
        public DbSet<Report> Reports { get; set; }

        public DbSet<admin> Admins { get; set; }
        public DbSet<NhanVien> NhanViens { get; set; }
    }
}