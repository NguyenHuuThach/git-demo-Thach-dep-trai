﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace QuanLyKhachSan.Models.Domain
{
    public class LoaiKhachHang
    {
        [Key]
        //[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id_Loai_khach_hang { get; set; }

        [Required]
        public string loai_khach { get; set; }

        public ICollection<Customer> Customers { get; set; }

        [NotMapped]
        public List<LoaiKhachHang> LoaiKhachHangCollection { get; set; }
    }
}