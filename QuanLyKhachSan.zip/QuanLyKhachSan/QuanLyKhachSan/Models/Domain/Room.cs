﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Web;

namespace QuanLyKhachSan.Models.Domain
{
    public class Room
    {
        public Room()
        {
            image_room = "~/Content/Images/addRoom.jpg";
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id_room { get; set; }

        [Required(ErrorMessage = "Vui long chon loai phong")]
        [ForeignKey("RoomDetail")]
        public int id_roomType { get; set; }
        public RoomDetail RoomDetail { get; set; }

        public string image_room { get; set; }

        public string tinhTrang { get; set; } = "Free";

        public string ghiChu { get; set; }

        public ICollection<PhieuThuePhong> PhieuThuePhongs { get; set; }

        [NotMapped]
        public int Price { get; set; }
        [NotMapped]
        public string ten_phong { get; set; }

        [NotMapped]
        public HttpPostedFileBase imageUpload { get; set; }

        [NotMapped]
        public List<Room> RoomCollection { get; set; }

        [NotMapped]
        public ICollection<RoomDetail> Room_Detail_collection { get; set; }
        
    }
}