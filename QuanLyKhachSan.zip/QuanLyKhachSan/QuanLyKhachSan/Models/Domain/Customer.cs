﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QuanLyKhachSan.Models.Domain
{
    public class Customer
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id_customer { get; set; }

        [Required(ErrorMessage = "Vui long nhap ten")]
        public string name_customer { get; set; }

        [Required(ErrorMessage = "Vui long nhap dia chi")]
        public string address_customer { get; set; }

        [Required(ErrorMessage = "Vui long chon loai khach")]
        [ForeignKey("LoaiKhachHang")]
        public int id_Loai_khach_hang { get; set; }
        public LoaiKhachHang LoaiKhachHang  { get; set; }

        [Required(ErrorMessage = "Vui long nhap email")]
        [RegularExpression(@"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}")]
        public string email_customer { get; set; }

        [Required(ErrorMessage = "Vui long nhap password")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,15}$")]
        [DataType(DataType.Password)]
        public string password_customer { get; set; }
        [NotMapped]
        [Required(ErrorMessage = "Vui long nhap lai password")]
        [System.ComponentModel.DataAnnotations.Compare("password_customer")]
        [RegularExpression(@"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,15}$")]
        [DataType(DataType.Password)]
        public string confirm_password_customer { get; set; }

        [NotMapped]
        public IEnumerable<LoaiKhachHang> loaiKhachHangs { get; set; }

        public ICollection<PhieuThuePhong> PhieuThuePhongs { get; set; }
    }
}