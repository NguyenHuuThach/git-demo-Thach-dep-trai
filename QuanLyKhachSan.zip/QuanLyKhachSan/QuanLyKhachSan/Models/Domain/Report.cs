﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace QuanLyKhachSan.Models.Domain
{
    public class Report
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id_report { get; set; }

        [DataType(DataType.Date)]
        public DateTime current_month { get; set; }
        public string loai_phong { get; set; }
        public int doanh_thu { get; set; }
        public double ti_le { get; set; }

    }
}