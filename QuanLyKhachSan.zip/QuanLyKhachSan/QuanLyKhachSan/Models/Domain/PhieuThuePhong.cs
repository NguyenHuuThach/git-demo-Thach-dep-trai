﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace QuanLyKhachSan.Models.Domain
{
    //public class PhieuThuePhongItem
    //{
    //    public Room _hotel_room { get; set; }
    //    //public int _list_quantity { get; set; }
    //}
    public class PhieuThuePhong
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id_phieu_thue_phong { get; set; }


        public int room_id { get; set; }
        [ForeignKey("room_id")]
        public Room Room { get; set; }


        public int customer_id { get; set; }
        [ForeignKey("customer_id")]
        public Customer Customer { get; set; }

        [NotMapped]
        public string Hinh_phong { get; set; }

        [NotMapped]
        public string Ten_phong { get; set; }

        [NotMapped]
        public int GiaPhong { get; set; }

        [NotMapped]
        public string ten_khach_hang { get; set; }

        [NotMapped]
        public int loai_khach_id { get; set; }

        [NotMapped]
        public string loai_khach { get; set; }

        [NotMapped]
        public int tong_so_ngay_thue { get; set; }

        [NotMapped]
        public int tong_don_gia { get; set; }

        [Required(ErrorMessage = "Moi ban nhap ngay bat dau nhan phong")]
        [DataType(DataType.Date)]
        public DateTime start_day { get; set; }

        [Required(ErrorMessage = "Moi ban nhap ngay tra phong")]
        [DataType(DataType.Date)]
        public DateTime end_day { get; set; }

        [Required(ErrorMessage = "Moi ban nhap so nguoi o")]
        public int so_luong_khach { get; set; }

        public bool have_Foreign { get; set; }

        public bool tinh_trang_phieu_thue_phong { get; set; } = false;
        

        [NotMapped]
        public ICollection<PhieuThuePhong> phieuThuePhongs { get; set; }

        //List<PhieuThuePhongItem> items = new List<PhieuThuePhongItem>();

        //public IEnumerable<PhieuThuePhongItem> Items
        //{
        //    get { return items; }
        //}

        //public void Them(Room room)
        //{
        //    var item = items.FirstOrDefault(s => s._hotel_room.id_room == room.id_room);
        //    if (item == null)
        //    {
        //        items.Add(new PhieuThuePhongItem
        //        {
        //            _hotel_room = room,
        //            //_list_quantity = _quantity
        //        });
        //    }
            
        //}

        //public void Update_quantity_SoLuongPhongDat(int id, int _quantity)
        //{
        //    var item = items.Find(s => s._hotel_room.id_room == id);
        //    if (item != null)
        //    {
        //        item._list_quantity = _quantity;
        //    }
        //}

        //public int Total_money()
        //{
        //    var total = items.Sum(s => s._hotel_room.Price);
        //    return total;
        //}

        //public void Huy_phong(int id)
        //{
        //    items.RemoveAll(s => s._hotel_room.id_room == id);
        //}

        //public int Total_Quantity()
        //{
        //    return items.Sum(s => s._list_quantity);
        //}
        //public void ClearPhieuThuePhong()
        //{
        //    items.Clear();
        //}
    }
}