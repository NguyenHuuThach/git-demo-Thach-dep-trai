﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace QuanLyKhachSan.Models.Domain
{
    public class RoomDetail
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id_roomType { get; set; }

        [Required(ErrorMessage = "Vui long nhap ten phong")]
        public string ten_phong { get; set; }

        [Required(ErrorMessage = "Vui long nhap gia phong")]
        public int Price { get; set; }

        [Required(ErrorMessage = "Vui long nhap so luong nguoi toi da trong phong")]
        public int SucChua { get; set; }

        public ICollection<Room> Rooms { get; set; }

        [NotMapped]
        public List<RoomDetail> RoomDetailCollection { get; set; }
    }
}