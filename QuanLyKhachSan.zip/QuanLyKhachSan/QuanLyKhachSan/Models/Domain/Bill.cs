﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace QuanLyKhachSan.Models.Domain
{
    public class Bill
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int id_bill { get; set; }

        public int phieu_thue_phong_id { get; set; }
        [ForeignKey("phieu_thue_phong_id")]
        public PhieuThuePhong PhieuThuePhong { get; set; }


        public int so_ngay_thue { get; set; }

        public int total_price { get; set; }

        //public Report Report { get; set; }
        //public ICollection<PhieuThuePhong> PhieuThuePhongs { get; set; }
    }
}