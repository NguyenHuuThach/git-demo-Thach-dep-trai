﻿namespace QuanLyKhachSan.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class _finalUpdate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.admins",
                c => new
                    {
                        ID_admin = c.Int(nullable: false, identity: true),
                        email_admin = c.String(nullable: false),
                        password_admin = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.ID_admin);
            
            CreateTable(
                "dbo.Bills",
                c => new
                    {
                        id_bill = c.Int(nullable: false, identity: true),
                        phieu_thue_phong_id = c.Int(nullable: false),
                        so_ngay_thue = c.Int(nullable: false),
                        total_price = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.id_bill)
                .ForeignKey("dbo.PhieuThuePhongs", t => t.phieu_thue_phong_id, cascadeDelete: true)
                .Index(t => t.phieu_thue_phong_id);
            
            CreateTable(
                "dbo.PhieuThuePhongs",
                c => new
                    {
                        id_phieu_thue_phong = c.Int(nullable: false, identity: true),
                        room_id = c.Int(nullable: false),
                        customer_id = c.Int(nullable: false),
                        start_day = c.DateTime(nullable: false),
                        end_day = c.DateTime(nullable: false),
                        so_luong_khach = c.Int(nullable: false),
                        have_Foreign = c.Boolean(nullable: false),
                        tinh_trang_phieu_thue_phong = c.Boolean(nullable: false),
                    })
                .PrimaryKey(t => t.id_phieu_thue_phong)
                .ForeignKey("dbo.Customers", t => t.customer_id, cascadeDelete: true)
                .ForeignKey("dbo.Rooms", t => t.room_id, cascadeDelete: true)
                .Index(t => t.room_id)
                .Index(t => t.customer_id);
            
            CreateTable(
                "dbo.Customers",
                c => new
                    {
                        id_customer = c.Int(nullable: false, identity: true),
                        name_customer = c.String(nullable: false),
                        address_customer = c.String(nullable: false),
                        id_Loai_khach_hang = c.Int(nullable: false),
                        email_customer = c.String(nullable: false),
                        password_customer = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.id_customer)
                .ForeignKey("dbo.LoaiKhachHangs", t => t.id_Loai_khach_hang, cascadeDelete: true)
                .Index(t => t.id_Loai_khach_hang);
            
            CreateTable(
                "dbo.LoaiKhachHangs",
                c => new
                    {
                        id_Loai_khach_hang = c.Int(nullable: false, identity: true),
                        loai_khach = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.id_Loai_khach_hang);
            
            CreateTable(
                "dbo.Rooms",
                c => new
                    {
                        id_room = c.Int(nullable: false, identity: true),
                        id_roomType = c.Int(nullable: false),
                        image_room = c.String(),
                        tinhTrang = c.String(),
                        ghiChu = c.String(),
                    })
                .PrimaryKey(t => t.id_room)
                .ForeignKey("dbo.RoomDetails", t => t.id_roomType, cascadeDelete: true)
                .Index(t => t.id_roomType);
            
            CreateTable(
                "dbo.RoomDetails",
                c => new
                    {
                        id_roomType = c.Int(nullable: false, identity: true),
                        ten_phong = c.String(nullable: false),
                        Price = c.Int(nullable: false),
                        SucChua = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.id_roomType);
            
            CreateTable(
                "dbo.NhanViens",
                c => new
                    {
                        ID_nhanVien = c.Int(nullable: false, identity: true),
                        email_nhanVien = c.String(nullable: false),
                        password_nhanVien = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.ID_nhanVien);
            
            CreateTable(
                "dbo.Reports",
                c => new
                    {
                        id_report = c.Int(nullable: false, identity: true),
                        current_month = c.DateTime(nullable: false),
                        loai_phong = c.String(),
                        doanh_thu = c.Int(nullable: false),
                        ti_le = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.id_report);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Bills", "phieu_thue_phong_id", "dbo.PhieuThuePhongs");
            DropForeignKey("dbo.Rooms", "id_roomType", "dbo.RoomDetails");
            DropForeignKey("dbo.PhieuThuePhongs", "room_id", "dbo.Rooms");
            DropForeignKey("dbo.PhieuThuePhongs", "customer_id", "dbo.Customers");
            DropForeignKey("dbo.Customers", "id_Loai_khach_hang", "dbo.LoaiKhachHangs");
            DropIndex("dbo.Rooms", new[] { "id_roomType" });
            DropIndex("dbo.Customers", new[] { "id_Loai_khach_hang" });
            DropIndex("dbo.PhieuThuePhongs", new[] { "customer_id" });
            DropIndex("dbo.PhieuThuePhongs", new[] { "room_id" });
            DropIndex("dbo.Bills", new[] { "phieu_thue_phong_id" });
            DropTable("dbo.Reports");
            DropTable("dbo.NhanViens");
            DropTable("dbo.RoomDetails");
            DropTable("dbo.Rooms");
            DropTable("dbo.LoaiKhachHangs");
            DropTable("dbo.Customers");
            DropTable("dbo.PhieuThuePhongs");
            DropTable("dbo.Bills");
            DropTable("dbo.admins");
        }
    }
}
